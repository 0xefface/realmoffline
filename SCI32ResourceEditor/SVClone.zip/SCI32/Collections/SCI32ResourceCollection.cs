﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCI32.Collections
{
    public class SCI32ResourceCollection : SCI32Collection<SCI32Resource>
    {
    }
}
